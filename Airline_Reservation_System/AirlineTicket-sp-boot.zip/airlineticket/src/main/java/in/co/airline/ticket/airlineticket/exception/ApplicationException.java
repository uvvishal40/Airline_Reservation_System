package in.co.airline.ticket.airlineticket.exception;



public class ApplicationException  extends Exception
{
	
	public ApplicationException(String msg) {
		super(msg);
	}
}
